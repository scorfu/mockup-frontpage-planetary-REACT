import Navbar from "../Components/ Navbar";

const Spaceships = () => {
    return <>
    <Navbar/>
    </>
}

export default Spaceships;