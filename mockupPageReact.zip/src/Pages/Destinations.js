import Navbar from "../Components/ Navbar";
const Destinations = () => {
    return <>
    <Navbar/>
    </>
}

export default Destinations;